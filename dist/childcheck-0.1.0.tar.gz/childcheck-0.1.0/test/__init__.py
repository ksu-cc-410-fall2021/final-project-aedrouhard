"""Test Package for childcheck.

Author: Allison Drouhard aedrouhard@ksu.edu
Version: 0.1
"""
