"""Meta package for all gui violence packages.

This is the __init__ file for this package.

Typically this file can be left blank.

Usage:
    python3 -m src/childcheck/gui/violence

Author: Allison Drouhard aedrouhard@ksu.edu
Version: 0.1
"""
