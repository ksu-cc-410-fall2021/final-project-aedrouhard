"""Meta package for all experience packages.

This is the __init__ file for this package.

Typically this file can be left blank.

Usage:
    python3 -m src/childcheck/data/experience

Author: Allison Drouhard aedrouhard@ksu.edu
Version: 0.1
"""
