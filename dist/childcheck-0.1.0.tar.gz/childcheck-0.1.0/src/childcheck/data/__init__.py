"""Meta package for data project package.

This is the __init__ file for this package.

Typically this file can be left blank.

Usage:
    python3 -m src/childcheck/data

Author: Allison Drouhard aedrouhard@ksu.edu
Version: 0.1
"""
