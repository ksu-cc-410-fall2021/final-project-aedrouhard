"""Meta package for all enum packages.

This is the __init__ file for this package.

Typically this file can be left blank.

Usage:
    python3 -m src/childcheck/data/enums

Author: Allison Drouhard aedrouhard@ksu.edu
Version: 0.1
"""
