"""Meta package for all gui packages.

This is the __init__ file for this package.

Typically this file can be left blank.

Usage:
    python3 -m src/childcheck/gui

Author: Allison Drouhard aedrouhard@ksu.edu
Version: 0.1
"""
